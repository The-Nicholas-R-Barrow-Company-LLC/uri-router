# URIRouter

## Format
{{scheme}}://{netloc}/{{path/more-path}}?{{param1=something}}&{{param2=somethingelse}}
{{scheme}}:///{{path/more-path}}?{{param1=something}}&{{param2=somethingelse}}